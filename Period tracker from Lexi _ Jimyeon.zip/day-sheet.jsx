// day-sheet.jsx — slide-up logging sheet + cycle editor

function DaySheet({ dateKey, entry, onUpdate, onClose }) {
  const date = fromYmd(dateKey);
  const today = new Date(); today.setHours(0,0,0,0);
  const isToday = sameYmd(date, today);
  const isFuture = date > today;

  // Close on Escape
  React.useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const toggleSym = (id) =>
    onUpdate((cur) => ({ ...cur, symptoms: { ...cur.symptoms, [id]: !cur.symptoms?.[id] } }));
  const toggleMoodFlag = (id) =>
    onUpdate((cur) => ({ ...cur, moodFlags: { ...cur.moodFlags, [id]: !cur.moodFlags?.[id] } }));
  const setDischarge = (id) =>
    onUpdate((cur) => ({ ...cur, discharge: cur.discharge === id ? null : id }));
  const setMood = (i) =>
    onUpdate((cur) => ({ ...cur, mood: cur.mood === i ? null : i }));
  const setWater = (n) => onUpdate({ water: Math.max(0, Math.min(10, n)) });
  const setDreams = (n) => onUpdate({ dreams: Math.max(0, n) });

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: 'absolute', inset: 0,
          background: 'rgba(42,31,26,0.45)',
          backdropFilter: 'blur(2px)',
          animation: 'fadeIn 0.2s ease', zIndex: 10,
        }}
      />

      {/* Sheet */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0,
        height: '88%',
        background: 'var(--bg)',
        borderTopLeftRadius: 28, borderTopRightRadius: 28,
        boxShadow: '0 -12px 40px rgba(42,31,26,0.18)',
        animation: 'sheetIn 0.3s cubic-bezier(.2,.7,.2,1)',
        display: 'flex', flexDirection: 'column',
        zIndex: 11, overflow: 'hidden',
      }}>
        {/* Handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '8px 0 4px' }}>
          <div style={{ width: 36, height: 4, borderRadius: 4, background: 'var(--line)' }} />
        </div>

        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
          padding: '4px 18px 12px',
          borderBottom: '1px solid var(--line-soft)',
        }}>
          <div>
            <div style={{
              fontSize: 10, letterSpacing: '0.18em', color: 'var(--gold-deep)',
              fontWeight: 600,
            }}>
              {isToday ? 'TODAY · 오늘' : isFuture ? 'UPCOMING · 예정' : 'LOG · 기록'}
            </div>
            <div className="serif" style={{
              fontSize: 22, fontWeight: 500, fontStyle: 'italic',
              color: 'var(--ink)', letterSpacing: '-0.01em', lineHeight: 1.15,
            }}>
              {dayLabel(date)}
            </div>
            <div style={{ fontSize: 10, color: 'var(--ink-mute)', marginTop: 2 }}>
              {date.toLocaleDateString('ko-KR', { weekday: 'long', month: 'long', day: 'numeric' })}
            </div>
          </div>
          <button onClick={onClose} style={sheetCloseStyle}>{ICONS.close}</button>
        </div>

        {/* Scrollable body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0 80px' }}>
          {/* PERIOD section */}
          <Section title="Period" ko="생리" accent="crimson">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
              <div style={{ fontSize: 12, color: 'var(--ink)' }}>
                Mark today as a period day
                <div style={{ fontSize: 10, color: 'var(--ink-mute)', marginTop: 2 }}>
                  Tap to toggle · 탭하여 표시
                </div>
              </div>
              <Switch
                value={!!entry.period}
                onChange={(v) => onUpdate({ period: v })}
                color="var(--crimson)"
              />
            </div>

            {entry.period && (
              <div style={{ marginTop: 14, animation: 'inkRise 0.3s ease' }}>
                <SubLabel>Flow · 양</SubLabel>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6, marginTop: 6 }}>
                  {[
                    { id: 'light', en: 'Light', ko: '적음', dots: 1 },
                    { id: 'medium', en: 'Medium', ko: '보통', dots: 2 },
                    { id: 'heavy', en: 'Heavy', ko: '많음', dots: 3 },
                  ].map((f) => (
                    <button
                      key={f.id}
                      onClick={() => onUpdate({ flow: f.id })}
                      style={{
                        padding: '10px 8px', borderRadius: 12,
                        background: entry.flow === f.id ? 'var(--crimson-wash)' : 'var(--card)',
                        border: entry.flow === f.id ? '1px solid var(--crimson)' : '1px solid var(--line-soft)',
                        color: 'var(--ink)', textAlign: 'left',
                      }}
                    >
                      <div style={{ display: 'flex', gap: 3, marginBottom: 6 }}>
                        {[...Array(3)].map((_, k) => (
                          <span key={k} style={{
                            width: 5, height: 5, borderRadius: 5,
                            background: k < f.dots ? 'var(--crimson)' : 'var(--line)',
                          }} />
                        ))}
                      </div>
                      <div style={{ fontSize: 12, fontWeight: 500, color: entry.flow === f.id ? 'var(--crimson-deep)' : 'var(--ink)' }}>
                        {f.en}
                      </div>
                      <div style={{ fontSize: 10, color: 'var(--ink-mute)' }}>{f.ko}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </Section>

          {/* SYMPTOMS */}
          <Section title="Symptoms" ko="증상" accent="gold">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 6 }}>
              {SYMPTOMS.map((s) => (
                <CheckTile
                  key={s.id}
                  checked={!!entry.symptoms?.[s.id]}
                  onChange={() => toggleSym(s.id)}
                  en={s.en} ko={s.ko}
                />
              ))}
            </div>
          </Section>

          {/* DISCHARGE */}
          <Section title="Discharge" ko="분비물" accent="gold">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
              {DISCHARGE.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setDischarge(d.id)}
                  style={{
                    padding: '10px 6px 8px', borderRadius: 12,
                    background: entry.discharge === d.id ? 'var(--bg-deep)' : 'var(--card)',
                    border: entry.discharge === d.id ? '1px solid var(--gold)' : '1px solid var(--line-soft)',
                    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5,
                  }}
                >
                  <span style={{
                    width: 22, height: 22, borderRadius: 22,
                    background: d.color, border: '1px solid var(--line)',
                  }} />
                  <span style={{ fontSize: 10, color: 'var(--ink)', textAlign: 'center', lineHeight: 1.15, fontWeight: 500 }}>
                    {d.en}
                  </span>
                  <span style={{ fontSize: 9, color: 'var(--ink-mute)' }}>{d.ko}</span>
                </button>
              ))}
            </div>
          </Section>

          {/* MOOD */}
          <Section title="Mood" ko="기분" accent="gold">
            <div style={{
              display: 'flex', justifyContent: 'space-between', gap: 6,
              padding: '10px 12px', borderRadius: 14,
              background: 'var(--card)', border: '1px solid var(--line-soft)',
            }}>
              {MOODS.map((_, i) => {
                const active = entry.mood === i;
                return (
                  <button
                    key={i}
                    onClick={() => setMood(i)}
                    style={{
                      flex: 1, padding: '6px 0', borderRadius: 10,
                      background: active ? 'var(--gold-wash)' : 'transparent',
                      border: active ? '1px solid var(--gold)' : '1px solid transparent',
                      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                      transition: 'all 120ms ease',
                    }}
                  >
                    <MoodFace index={i} size={32} active={active} />
                  </button>
                );
              })}
            </div>
            {entry.mood != null && (
              <div style={{
                fontSize: 10, color: 'var(--ink-soft)', marginTop: 6, textAlign: 'center',
                fontStyle: 'italic',
              }} className="serif">
                {MOOD_LABELS[entry.mood]}
              </div>
            )}

            <SubLabel style={{ marginTop: 14 }}>Mood flags · 추가 기분</SubLabel>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
              {MOOD_FLAGS.map((f) => {
                const on = !!entry.moodFlags?.[f.id];
                return (
                  <button
                    key={f.id}
                    onClick={() => toggleMoodFlag(f.id)}
                    style={{
                      padding: '7px 11px', borderRadius: 999,
                      background: on ? 'var(--gold-wash)' : 'var(--card)',
                      border: on ? '1px solid var(--gold)' : '1px solid var(--line-soft)',
                      fontSize: 11, color: on ? 'var(--gold-deep)' : 'var(--ink-soft)',
                      display: 'inline-flex', alignItems: 'center', gap: 6, fontWeight: on ? 500 : 400,
                    }}
                  >
                    <span style={{
                      width: 5, height: 5, borderRadius: 5,
                      background: on ? 'var(--gold)' : 'var(--line)',
                    }} />
                    <span>{f.en}</span>
                    <span style={{ color: 'var(--ink-mute)', fontSize: 10 }}>· {f.ko}</span>
                  </button>
                );
              })}
            </div>
          </Section>

          {/* WATER */}
          <Section title="Water" ko="물" accent="gold">
            <div style={{
              padding: '12px 14px', borderRadius: 14,
              background: 'var(--card)', border: '1px solid var(--line-soft)',
            }}>
              <div style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
                marginBottom: 10,
              }}>
                <span style={{ fontSize: 11, color: 'var(--ink-soft)' }}>
                  Tap a drop to log a cup
                </span>
                <span className="serif" style={{
                  fontSize: 18, fontStyle: 'italic',
                  color: 'var(--ink)',
                }}>
                  {entry.water}<span style={{ color: 'var(--ink-mute)', fontSize: 13 }}>/8 cups</span>
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 4 }}>
                {[...Array(8)].map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setWater(i + 1 === entry.water ? i : i + 1)}
                    style={{ padding: 2, lineHeight: 0 }}
                    aria-label={`Set water to ${i + 1}`}
                  >
                    {ICONS.drop(i < entry.water, i < entry.water ? '#7CA7D0' : '#C9DCE9')}
                  </button>
                ))}
              </div>
            </div>
          </Section>

          {/* OTHER */}
          <Section title="Other" ko="기타" accent="gold">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 6 }}>
              <CheckTile
                checked={entry.medicine}
                onChange={() => onUpdate({ medicine: !entry.medicine })}
                en="Medicine" ko="약 (cycle impact)"
              />
              <CheckTile
                checked={entry.heatpad}
                onChange={() => onUpdate({ heatpad: !entry.heatpad })}
                en="Heat pad" ko="찜질팩"
              />
              <CheckTile
                checked={entry.palpitations}
                onChange={() => onUpdate({ palpitations: !entry.palpitations })}
                en="Heart palpitations" ko="심장 두근거림"
              />
              <Counter
                label="Dreams" ko="꿈"
                value={entry.dreams}
                onChange={setDreams}
              />
            </div>
          </Section>

          {/* NOTES */}
          <Section title="Notes" ko="메모" accent="gold">
            <textarea
              value={entry.notes}
              onChange={(e) => onUpdate({ notes: e.target.value })}
              placeholder="A little note for today… · 오늘의 메모…"
              style={{
                width: '100%', minHeight: 60, resize: 'vertical',
                padding: '10px 12px', borderRadius: 12,
                background: 'var(--card)', border: '1px solid var(--line-soft)',
                fontSize: 12, color: 'var(--ink)', outline: 'none', boxSizing: 'border-box',
                fontFamily: 'inherit', lineHeight: 1.5,
              }}
              onFocus={(e) => e.target.style.borderColor = 'var(--gold)'}
              onBlur={(e) => e.target.style.borderColor = 'var(--line-soft)'}
            />
          </Section>

          {/* Done */}
          <div style={{ padding: '4px 18px 0' }}>
            <button
              onClick={onClose}
              style={{
                width: '100%', padding: '12px 16px', borderRadius: 14,
                background: 'var(--ink)', color: '#fff',
                fontSize: 12, letterSpacing: '0.14em', fontWeight: 500,
              }}
            >
              SAVED · 저장됨
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

// ── Section wrapper ────────────────────────────────────────────────────
function Section({ title, ko, accent, children }) {
  return (
    <div style={{ padding: '14px 18px 6px' }}>
      <div style={{ marginBottom: 10, display: 'flex', alignItems: 'baseline', gap: 8 }}>
        <span style={{
          width: 4, height: 14, borderRadius: 4,
          background: accent === 'crimson' ? 'var(--crimson)' : 'var(--gold)',
          display: 'inline-block', transform: 'translateY(2px)',
        }} />
        <span className="serif" style={{
          fontSize: 18, fontStyle: 'italic', color: 'var(--ink)', fontWeight: 500,
        }}>{title}</span>
        <span style={{ fontSize: 11, color: 'var(--ink-mute)' }}>· {ko}</span>
      </div>
      {children}
    </div>
  );
}

function SubLabel({ children, style }) {
  return (
    <div style={{
      fontSize: 10, letterSpacing: '0.16em', color: 'var(--ink-mute)',
      fontWeight: 600, ...style,
    }}>{children}</div>
  );
}

function CheckTile({ checked, onChange, en, ko }) {
  return (
    <button
      onClick={onChange}
      style={{
        textAlign: 'left',
        padding: '10px 12px', borderRadius: 12,
        background: checked ? 'var(--gold-wash)' : 'var(--card)',
        border: checked ? '1px solid var(--gold)' : '1px solid var(--line-soft)',
        display: 'flex', alignItems: 'center', gap: 9,
        transition: 'all 120ms ease',
      }}
    >
      <span style={{
        width: 16, height: 16, borderRadius: 4,
        background: checked ? 'var(--gold)' : 'transparent',
        border: checked ? '1px solid var(--gold)' : '1.2px solid var(--line)',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        flexShrink: 0,
      }}>
        {checked && (
          <svg width="10" height="10" viewBox="0 0 10 10"><path d="M1.5 5l2.5 2.5L8.5 2" stroke="white" strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
        )}
      </span>
      <span style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 12, color: 'var(--ink)', fontWeight: checked ? 500 : 400 }}>{en}</div>
        <div style={{ fontSize: 9.5, color: 'var(--ink-mute)' }}>{ko}</div>
      </span>
    </button>
  );
}

function Counter({ label, ko, value, onChange }) {
  return (
    <div style={{
      padding: '10px 12px', borderRadius: 12,
      background: value > 0 ? 'var(--gold-wash)' : 'var(--card)',
      border: value > 0 ? '1px solid var(--gold)' : '1px solid var(--line-soft)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8,
    }}>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 12, color: 'var(--ink)', fontWeight: value > 0 ? 500 : 400 }}>{label}</div>
        <div style={{ fontSize: 9.5, color: 'var(--ink-mute)' }}>{ko}</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
        <button onClick={() => onChange(value - 1)} style={counterBtn} aria-label="Decrease">
          {ICONS.minus}
        </button>
        <span className="serif" style={{
          fontSize: 18, fontStyle: 'italic', minWidth: 18, textAlign: 'center', color: 'var(--ink)',
        }}>{value}</span>
        <button onClick={() => onChange(value + 1)} style={counterBtn} aria-label="Increase">
          {ICONS.plus}
        </button>
      </div>
    </div>
  );
}

function Switch({ value, onChange, color = 'var(--gold)' }) {
  return (
    <button
      onClick={() => onChange(!value)}
      style={{
        width: 46, height: 26, borderRadius: 26, padding: 2,
        background: value ? color : 'var(--line)',
        display: 'inline-flex', alignItems: 'center',
        transition: 'background 200ms ease',
        flexShrink: 0,
      }}
    >
      <span style={{
        width: 22, height: 22, borderRadius: 22, background: '#fff',
        boxShadow: '0 1px 3px rgba(0,0,0,0.18)',
        transform: value ? 'translateX(20px)' : 'translateX(0)',
        transition: 'transform 200ms cubic-bezier(.5,.0,.2,1)',
      }} />
    </button>
  );
}

const counterBtn = {
  width: 26, height: 26, borderRadius: 26,
  background: 'var(--card)', border: '1px solid var(--line)',
  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
  color: 'var(--ink-soft)',
};

const sheetCloseStyle = {
  width: 30, height: 30, borderRadius: 30,
  background: 'var(--card)', border: '1px solid var(--line-soft)',
  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
  color: 'var(--ink-soft)', flexShrink: 0,
};

// ── Cycle Editor ────────────────────────────────────────────────────────
function CycleEditor({ cycleLength, setCycleLength, onClose }) {
  const [val, setVal] = React.useState(cycleLength);

  return (
    <>
      <div
        onClick={onClose}
        style={{
          position: 'absolute', inset: 0,
          background: 'rgba(42,31,26,0.45)', backdropFilter: 'blur(2px)',
          animation: 'fadeIn 0.2s ease', zIndex: 20,
        }}
      />
      <div style={{
        position: 'absolute', left: 18, right: 18, top: '32%',
        background: 'var(--bg)', borderRadius: 22,
        padding: '20px 20px 16px',
        boxShadow: '0 20px 50px rgba(42,31,26,0.25)',
        animation: 'inkRise 0.3s ease', zIndex: 21,
        border: '1px solid var(--line)',
      }}>
        <div style={{
          fontSize: 10, letterSpacing: '0.2em', color: 'var(--gold-deep)',
          fontWeight: 600, marginBottom: 4,
        }}>ADJUST CYCLE · 주기 조정</div>
        <div className="serif" style={{
          fontSize: 22, fontStyle: 'italic', color: 'var(--ink)', marginBottom: 14,
        }}>
          Your average cycle length
        </div>
        <div style={{ fontSize: 11, color: 'var(--ink-soft)', lineHeight: 1.5, marginBottom: 16 }}>
          Perimenopause often makes cycles irregular. Adjust this whenever your rhythm shifts —
          predictions will recalculate.
          <br/>
          <span style={{ fontStyle: 'italic' }}>완경기에는 주기가 불규칙해요. 언제든 조정 가능.</span>
        </div>

        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '12px 14px', borderRadius: 14,
          background: 'var(--card)', border: '1px solid var(--line-soft)',
        }}>
          <button onClick={() => setVal((v) => Math.max(14, v - 1))} style={counterBtn}>{ICONS.minus}</button>
          <div style={{ textAlign: 'center' }}>
            <div className="serif" style={{
              fontSize: 44, lineHeight: 1, fontStyle: 'italic', color: 'var(--ink)',
              fontWeight: 500,
            }}>{val}</div>
            <div style={{ fontSize: 10, color: 'var(--ink-mute)', letterSpacing: '0.14em', marginTop: 2 }}>
              DAYS · 일
            </div>
          </div>
          <button onClick={() => setVal((v) => Math.min(60, v + 1))} style={counterBtn}>{ICONS.plus}</button>
        </div>

        <input
          type="range" min={14} max={60} step={1} value={val}
          onChange={(e) => setVal(Number(e.target.value))}
          style={{ width: '100%', marginTop: 14, accentColor: 'var(--gold)' }}
        />

        <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
          <button
            onClick={onClose}
            style={{
              flex: 1, padding: '11px', borderRadius: 12,
              background: 'var(--card)', border: '1px solid var(--line)',
              color: 'var(--ink-soft)', fontSize: 12, fontWeight: 500,
              letterSpacing: '0.1em',
            }}
          >CANCEL · 취소</button>
          <button
            onClick={() => { setCycleLength(val); onClose(); }}
            style={{
              flex: 1, padding: '11px', borderRadius: 12,
              background: 'var(--ink)', color: '#fff',
              fontSize: 12, fontWeight: 500, letterSpacing: '0.1em',
            }}
          >SAVE · 저장</button>
        </div>
      </div>
    </>
  );
}

Object.assign(window, { DaySheet, CycleEditor });
