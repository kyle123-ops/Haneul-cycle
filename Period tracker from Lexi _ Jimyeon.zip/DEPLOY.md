# 하늘's Cycle — GitHub setup

You already made the repo — perfect. Here's how to get the code in.

## 🌸 Option A — Upload via GitHub web (easiest, no terminal)

1. **Download the project zip** using the download card I sent in chat
2. Unzip it on your computer
3. Open your empty repo on github.com
4. Click **"uploading an existing file"** (link on the empty-repo page) — or **Add file → Upload files**
5. **Drag the entire contents** of the unzipped folder into the browser
   - ⚠️ Drag the **contents** (index.html, app.jsx, assets/, etc.), not the parent folder
6. Scroll down, write a tiny commit message like "first commit ♡", click **Commit changes**

That's it. The upload takes ~30 seconds.

## 🌸 Option B — From the command line (if you're comfy with git)

```bash
cd /path/to/unzipped-project
git init
git add .
git commit -m "first commit ♡"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

## 🌸 Then turn it on as a live app

1. In your repo → **Settings** (top tab) → **Pages** (left sidebar)
2. Under **Build and deployment** → **Source**: choose **Deploy from a branch**
3. **Branch**: pick `main`, folder `/ (root)` → click **Save**
4. Wait ~1 minute. Refresh the Pages settings page — a green box appears with your URL
5. The URL looks like: `https://<your-username>.github.io/<repo-name>/`

## 🌸 Install on your phone

**iPhone (Safari):**
1. Open the URL in Safari (must be Safari, not Chrome, for full PWA on iOS)
2. Tap the **Share** button (square with arrow up)
3. Scroll down → **Add to Home Screen**
4. Name it (default: "하늘's Cycle") → **Add**

**Android (Chrome):**
1. Open the URL in Chrome
2. Tap the **⋮** menu → **Install app** (or **Add to Home Screen**)
3. Confirm

Now it lives on your home screen like any other app. Opens fullscreen, no browser bar. Works offline. Data stays on your phone.

## 🌸 Pushing updates later

When I (or you) change code, you can update the live app by:
- Web: open the file in your repo on github.com, click the pencil ✏️, paste new content, commit
- Git: `git add . && git commit -m "update" && git push`

GitHub Pages auto-rebuilds in ~30 seconds. Refresh the app once and you'll see the new version. (The service worker may cache the old version briefly — to force-refresh on iPhone: tap-and-hold the app icon → **Delete App** → reinstall from Safari. Or bump the `VERSION` string in `service-worker.js` before pushing.)

---

Stuck on any step? Tell me where and I'll walk you through it. 🩷
