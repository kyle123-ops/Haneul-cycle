// app.jsx — main shell for 하늘's Cycle. Wires storage + DaySheet + Calendar.

const { useState, useEffect, useMemo, useRef } = React;

// ── Data model ──────────────────────────────────────────────────────────
// Per-day entry:
//  { period: bool, flow: 'light'|'medium'|'heavy',
//    symptoms: { nightsweats, headache, ... },
//    discharge: 'white'|'slight-yellow'|'eggwhite'|'pinkish'|null,
//    mood: 0..4, moodFlags: { anxiety, intrusive, swings, sadness, arousal },
//    water: int (0..10),
//    medicine: bool, heatpad: bool, palpitations: bool,
//    dreams: int, notes: string }

const STORAGE_KEY = 'haneul-cycle-v1';
const CYCLE_LEN_KEY = 'haneul-cycle-length-v1';

const SYMPTOMS = [
  { id: 'nightsweats', en: 'Night sweats', ko: '식은땀' },
  { id: 'headache', en: 'Headache', ko: '두통' },
  { id: 'nausea', en: 'Nausea', ko: '메스꺼움' },
  { id: 'cramps', en: 'Gentle cramps', ko: '복통' },
  { id: 'exhaustion', en: 'Exhaustion', ko: '피로' },
  { id: 'hunger', en: 'Hunger', ko: '배고픔' },
  { id: 'legtremors', en: 'Leg tremors', ko: '다리 떨림' },
  { id: 'brainfog', en: 'Brain fog', ko: '브레인 포그' },
  { id: 'vertigo', en: 'Vertigo', ko: '어지럼' },
  { id: 'breasts', en: 'Swollen breasts', ko: '가슴 부음' },
  { id: 'diarrhea', en: 'Diarrhea', ko: '설사' },
  { id: 'constipation', en: 'Constipation', ko: '변비' },
];

const DISCHARGE = [
  { id: 'white', en: 'White', ko: '흰색', color: '#f7f3ea' },
  { id: 'slight-yellow', en: 'Slight yellow', ko: '연노랑', color: '#f7eecf' },
  { id: 'eggwhite', en: 'Egg white', ko: '계란 흰자', color: '#eef3ea' },
  { id: 'pinkish', en: 'Pinkish', ko: '분홍', color: '#f7dde2' },
];

const MOODS = ['😁', '😊', '😐', '😢', '😰'];
const MOOD_LABELS = ['Joyful · 즐거움', 'Calm · 평온', 'Neutral · 보통', 'Sad · 슬픔', 'Anxious · 불안'];

const MOOD_FLAGS = [
  { id: 'anxiety', en: 'Anxiety', ko: '불안' },
  { id: 'intrusive', en: 'Intrusive thoughts', ko: '강박적 생각' },
  { id: 'swings', en: 'Mood swings', ko: '기분 변화' },
  { id: 'sadness', en: 'Sadness', ko: '우울' },
  { id: 'arousal', en: 'Extreme arousal', ko: '극도 흥분' },
];

const blankEntry = () => ({
  period: false, flow: 'medium',
  symptoms: {}, discharge: null,
  mood: null, moodFlags: {},
  water: 0, medicine: false, heatpad: false, palpitations: false,
  dreams: 0, notes: '',
});

// ── Tweak defaults (host can rewrite this block on disk) ────────────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#B8954B",
  "showCreatorNote": true,
  "deviceFrame": true,
  "bgPhoto": true,
  "bgOverlay": 68
}/*EDITMODE-END*/;

// Seed sample data for demo / first load
function seedSample() {
  const today = new Date(); today.setHours(0,0,0,0);
  const out = {};
  // Last period: started ~16 days ago, lasted 5 days
  const lastStart = addDays(today, -16);
  for (let i = 0; i < 5; i++) {
    const k = ymd(addDays(lastStart, i));
    out[k] = {
      ...blankEntry(),
      period: true,
      flow: i === 0 ? 'light' : i === 1 || i === 2 ? 'heavy' : i === 3 ? 'medium' : 'light',
      symptoms: i === 1 ? { cramps: true, exhaustion: true, headache: true } : i === 2 ? { cramps: true, brainfog: true } : { exhaustion: true },
      mood: i === 1 ? 3 : 2,
      water: i === 1 ? 4 : 6,
      heatpad: i <= 2,
      medicine: i === 1,
      notes: i === 1 ? 'Cramps worse than usual today. Heat pad helping.' : '',
    };
  }
  // A few non-period days with mood / symptoms (perimenopause patterns)
  out[ymd(addDays(today, -10))] = { ...blankEntry(), symptoms: { nightsweats: true, brainfog: true }, mood: 2, water: 5, dreams: 2 };
  out[ymd(addDays(today, -7))] = { ...blankEntry(), symptoms: { hunger: true, vertigo: true }, mood: 1, water: 7 };
  out[ymd(addDays(today, -3))] = { ...blankEntry(), symptoms: { headache: true, nightsweats: true }, mood: 3, moodFlags: { swings: true }, palpitations: true, water: 4, notes: 'Hot flash around 2am' };
  out[ymd(today)] = { ...blankEntry(), symptoms: { exhaustion: true }, mood: 2, water: 3, dreams: 1 };
  return out;
}

// ── App ────────────────────────────────────────────────────────────────
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // entries + cycle length, persisted
  const [entries, setEntries] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch (_) {}
    return seedSample();
  });
  const [cycleLength, setCycleLength] = useState(() => {
    try {
      const v = Number(localStorage.getItem(CYCLE_LEN_KEY));
      if (v && v >= 14 && v <= 60) return v;
    } catch (_) {}
    return 28;
  });

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(entries)); } catch (_) {}
  }, [entries]);
  useEffect(() => {
    try { localStorage.setItem(CYCLE_LEN_KEY, String(cycleLength)); } catch (_) {}
  }, [cycleLength]);

  const today = useMemo(() => { const d = new Date(); d.setHours(0,0,0,0); return d; }, []);
  const [monthCursor, setMonthCursor] = useState(() => {
    const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1);
  });
  const [selectedYmd, setSelectedYmd] = useState(null);
  const [showCycleEdit, setShowCycleEdit] = useState(false);

  const info = useMemo(() => cycleInfo(entries, cycleLength), [entries, cycleLength]);

  const onPickDay = (d) => {
    setSelectedYmd(ymd(d));
  };

  const updateEntry = (key, patch) => {
    setEntries((prev) => {
      const cur = prev[key] || blankEntry();
      const next = typeof patch === 'function' ? patch(cur) : { ...cur, ...patch };
      return { ...prev, [key]: next };
    });
  };

  const todayKey = ymd(today);
  const todayEntry = entries[todayKey] || blankEntry();

  const overlayAlpha = Math.max(0, Math.min(100, t.bgOverlay)) / 100;
  const bgStyle = t.bgPhoto
    ? {
        backgroundImage: `linear-gradient(180deg, rgba(251,247,239,${overlayAlpha}) 0%, rgba(251,247,239,${Math.min(1, overlayAlpha + 0.04)}) 60%, rgba(243,236,222,${Math.min(1, overlayAlpha + 0.08)}) 100%), url("assets/haneul-photo.jpg")`,
        backgroundSize: 'cover, cover',
        backgroundPosition: 'center, center 30%',
        backgroundRepeat: 'no-repeat, no-repeat',
      }
    : { background: 'var(--bg)' };

  const content = (
    <div style={{
      width: '100%', height: '100%',
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
      position: 'relative',
      ...bgStyle,
    }}>
      {/* Decorative gold rule under status bar area */}
      <div style={{
        flex: 1, overflowY: 'auto', overflowX: 'hidden',
        paddingTop: 6, paddingBottom: 24,
      }}>
        <Header showNote={t.showCreatorNote} />
        <StatusCard
          info={info}
          cycleLength={cycleLength}
          onEditCycle={() => setShowCycleEdit(true)}
        />
        <Calendar
          monthCursor={monthCursor}
          setMonthCursor={setMonthCursor}
          entries={entries}
          predictedStart={info.nextStart}
          onPickDay={onPickDay}
          selectedYmd={selectedYmd}
        />
        <TodayPeek
          entry={todayEntry}
          todayDate={today}
          onOpen={() => setSelectedYmd(todayKey)}
        />
        <PatternStrip entries={entries} info={info} />
        <Footer />
      </div>

      {/* Day Sheet */}
      {selectedYmd && (
        <DaySheet
          dateKey={selectedYmd}
          entry={entries[selectedYmd] || blankEntry()}
          onUpdate={(patch) => updateEntry(selectedYmd, patch)}
          onClose={() => setSelectedYmd(null)}
        />
      )}

      {/* Cycle Length Editor */}
      {showCycleEdit && (
        <CycleEditor
          cycleLength={cycleLength}
          setCycleLength={setCycleLength}
          onClose={() => setShowCycleEdit(false)}
        />
      )}
    </div>
  );

  return (
    <>
      {t.deviceFrame ? (
        <IOSDevice width={402} height={874} title="하늘's Cycle" dark={false}>
          {content}
        </IOSDevice>
      ) : (
        <div style={{
          width: 402, height: 874, borderRadius: 28, overflow: 'hidden',
          boxShadow: '0 30px 80px rgba(0,0,0,0.45)', border: '1px solid #2a221a',
        }}>{content}</div>
      )}

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme · 테마">
          <TweakColor
            label="Accent"
            value={t.accent}
            options={['#B8954B', '#9B7B2E', '#C9A24A', '#7A6BAE']}
            onChange={(v) => {
              setTweak('accent', v);
              document.documentElement.style.setProperty('--gold', v);
            }}
          />
          <TweakToggle
            label="Creator note · 메모"
            value={t.showCreatorNote}
            onChange={(v) => setTweak('showCreatorNote', v)}
          />
          <TweakToggle
            label="Device frame"
            value={t.deviceFrame}
            onChange={(v) => setTweak('deviceFrame', v)}
          />
        </TweakSection>
        <TweakSection label="Background · 배경">
          <TweakToggle
            label="Photo overlay · 사진"
            value={t.bgPhoto}
            onChange={(v) => setTweak('bgPhoto', v)}
          />
          <TweakSlider
            label="Overlay strength"
            value={t.bgOverlay}
            min={50} max={98} step={1} unit="%"
            onChange={(v) => setTweak('bgOverlay', v)}
          />
        </TweakSection>
        <TweakSection label="Data">
          <TweakButton
            label="Reset to sample data"
            secondary
            onClick={() => { setEntries(seedSample()); setSelectedYmd(null); }}
          />
          <TweakButton
            label="Clear all entries"
            secondary
            onClick={() => { setEntries({}); setSelectedYmd(null); }}
          />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

// ── Header ─────────────────────────────────────────────────────────────
function Header({ showNote }) {
  return (
    <div style={{ padding: '6px 18px 14px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{
            fontSize: 10, letterSpacing: '0.22em', color: 'var(--gold-deep)',
            fontWeight: 600,
          }}>HANEUL · 하늘</div>
          <div className="serif" style={{
            fontSize: 26, fontWeight: 500, fontStyle: 'italic',
            color: 'var(--ink)', letterSpacing: '-0.01em', lineHeight: 1.1, marginTop: 2,
          }}>
            Your Cycle <span style={{ color: 'var(--crimson)' }}>·</span> 너의 주기
          </div>
        </div>
        <div style={{
          width: 38, height: 38, borderRadius: 38,
          background: 'linear-gradient(135deg, var(--gold-wash), var(--gold-soft))',
          border: '1px solid var(--gold-soft)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--gold-deep)', fontWeight: 600, fontSize: 13,
        }} className="serif">하</div>
      </div>

      {showNote && (
        <div style={{
          marginTop: 12, padding: '10px 12px',
          background: 'var(--crimson-wash)',
          border: '1px solid var(--crimson-soft)',
          borderRadius: 12,
          display: 'flex', alignItems: 'center', gap: 10,
          animation: 'inkRise 0.6s ease',
        }}>
          <span className="pulse-heart" style={{ display: 'inline-flex' }}>
            {ICONS.heart(14, '#9B1C2F')}
          </span>
          <div style={{ flex: 1, fontSize: 11, color: 'var(--ink)', lineHeight: 1.5 }}>
            <div style={{ fontWeight: 500 }}>Made for 하늘 with love</div>
            <div style={{ color: 'var(--ink-soft)' }}>
              사랑해, <span className="serif" style={{ fontStyle: 'italic', fontSize: 13 }}>레이 &amp; 지면</span> ♡
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── TodayPeek: small card showing today's logged items ──────────────────
function TodayPeek({ entry, todayDate, onOpen }) {
  const symptomCount = Object.values(entry.symptoms || {}).filter(Boolean).length;
  const flagCount = Object.values(entry.moodFlags || {}).filter(Boolean).length;

  return (
    <button
      onClick={onOpen}
      style={{
        display: 'block', textAlign: 'left',
        margin: '4px 18px 14px',
        width: 'calc(100% - 36px)',
        background: 'var(--card)',
        border: '1px solid var(--line-soft)',
        borderRadius: 16, padding: '14px 16px',
        position: 'relative',
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontSize: 10, letterSpacing: '0.18em', color: 'var(--gold-deep)', fontWeight: 600 }}>
            TODAY · 오늘
          </div>
          <div className="serif" style={{
            fontSize: 20, fontStyle: 'italic', marginTop: 2, color: 'var(--ink)',
          }}>
            {todayDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}
          </div>
        </div>
        <span style={{
          fontSize: 10, color: 'var(--ink-mute)', letterSpacing: '0.1em',
          display: 'inline-flex', alignItems: 'center', gap: 4,
        }}>
          LOG <span style={{ color: 'var(--gold)' }}>{ICONS.chevR}</span>
        </span>
      </div>

      <div style={{
        display: 'flex', gap: 10, marginTop: 12, flexWrap: 'wrap',
      }}>
        {entry.mood != null && (
          <PeekChip icon={<MoodFace index={entry.mood} size={16} />} text={MOOD_LABELS[entry.mood].split(' ·')[0]} />
        )}
        {entry.water > 0 && (
          <PeekChip text={`${entry.water}/8 cups · 물`} dotColor="#7CA7D0" />
        )}
        {symptomCount > 0 && (
          <PeekChip text={`${symptomCount} symptom${symptomCount > 1 ? 's' : ''} · 증상`} dotColor="var(--crimson)" />
        )}
        {flagCount > 0 && (
          <PeekChip text={`${flagCount} mood flag${flagCount > 1 ? 's' : ''}`} dotColor="var(--gold)" />
        )}
        {entry.medicine && <PeekChip text="Medicine · 약" dotColor="var(--gold-deep)" />}
        {entry.heatpad && <PeekChip text="Heat pad · 찜질" dotColor="var(--crimson)" />}
        {entry.palpitations && <PeekChip text="Palpitations · 심장두근" dotColor="var(--crimson-deep)" />}
        {entry.dreams > 0 && <PeekChip text={`${entry.dreams} dream${entry.dreams > 1 ? 's' : ''} · 꿈`} dotColor="var(--ink-soft)" />}
        {entry.mood == null && symptomCount === 0 && entry.water === 0 && !entry.medicine && !entry.heatpad && !entry.palpitations && entry.dreams === 0 && (
          <span style={{ fontSize: 11, color: 'var(--ink-mute)', fontStyle: 'italic' }}>
            Nothing logged yet — tap to begin · 아직 없음
          </span>
        )}
      </div>
    </button>
  );
}

function PeekChip({ icon, text, dotColor }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '5px 9px', borderRadius: 999,
      background: 'var(--bg)', border: '1px solid var(--line-soft)',
      fontSize: 10.5, color: 'var(--ink)',
    }}>
      {icon && <span style={{ display: 'inline-flex' }}>{icon}</span>}
      {dotColor && !icon && (
        <span style={{ width: 6, height: 6, borderRadius: 6, background: dotColor }} />
      )}
      <span>{text}</span>
    </span>
  );
}

// ── Pattern Strip: tiny 4-week mood + period overview ───────────────────
function PatternStrip({ entries, info }) {
  const today = new Date(); today.setHours(0,0,0,0);
  const days = [];
  for (let i = 27; i >= 0; i--) days.push(addDays(today, -i));

  return (
    <div style={{ margin: '0 18px 14px' }}>
      <div style={{
        display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
        marginBottom: 8,
      }}>
        <div>
          <div style={{ fontSize: 10, letterSpacing: '0.18em', color: 'var(--gold-deep)', fontWeight: 600 }}>
            PATTERN · 패턴
          </div>
          <div className="serif" style={{ fontSize: 16, fontStyle: 'italic', color: 'var(--ink)', marginTop: 1 }}>
            Last 28 days
          </div>
        </div>
        <span style={{ fontSize: 10, color: 'var(--ink-mute)' }}>perimenopausal rhythm</span>
      </div>

      <div style={{
        display: 'flex', gap: 2, alignItems: 'flex-end',
        background: 'var(--card)', borderRadius: 12, padding: 10,
        border: '1px solid var(--line-soft)',
        height: 76, position: 'relative',
      }}>
        {days.map((d, i) => {
          const e = entries[ymd(d)];
          const isPeriod = !!e?.period;
          const sympCount = e ? Object.values(e.symptoms || {}).filter(Boolean).length : 0;
          // Bar height encodes symptom load
          const h = Math.max(6, Math.min(56, sympCount * 12 + (isPeriod ? 20 : 0)));
          return (
            <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-end', height: '100%' }}>
              <div style={{
                width: '100%',
                height: h,
                borderRadius: 3,
                background: isPeriod
                  ? 'linear-gradient(180deg, var(--crimson), var(--crimson-deep))'
                  : sympCount > 0 ? 'var(--gold-soft)' : 'var(--line-soft)',
                opacity: sympCount === 0 && !isPeriod ? 0.6 : 1,
              }} />
            </div>
          );
        })}
      </div>
      <div style={{
        display: 'flex', justifyContent: 'space-between', marginTop: 6,
        fontSize: 9, color: 'var(--ink-mute)', letterSpacing: '0.1em',
      }}>
        <span>4 WEEKS AGO</span><span>TODAY</span>
      </div>
    </div>
  );
}

// ── Footer ─────────────────────────────────────────────────────────────
function Footer() {
  return (
    <div style={{
      margin: '6px 18px 0', padding: '14px 0 6px',
      borderTop: '1px dashed var(--line)',
      textAlign: 'center',
    }}>
      <div className="serif" style={{
        fontSize: 13, fontStyle: 'italic', color: 'var(--ink-soft)',
      }}>
        Tracked gently. <span style={{ color: 'var(--crimson)' }}>♡</span> 천천히 함께
      </div>
      <div style={{ fontSize: 9, color: 'var(--ink-mute)', letterSpacing: '0.16em', marginTop: 4 }}>
        FROM 레이 &amp; 지면 · FOR 하늘
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
