# 하늘's Cycle 💕

A gentle perimenopause tracker. Made for 하늘 with love by 레이 & 지면.

## What's inside
- Monthly calendar with pulsing crimson hearts on period days + predicted-start markers
- Day-by-day logging: flow intensity, 12 symptoms, discharge, 5 mood faces + mood flags, water, medicine, heat pad, palpitations, dreams, free-text notes
- Cycle prediction with adjustable cycle length (handles perimenopausal irregularity)
- 28-day pattern strip
- Soft photo background overlay
- Korean + English everywhere
- Works **offline** once installed (service worker)
- **Installable** to home screen on iOS + Android (PWA)
- Data lives in browser `localStorage` — private, on-device only

## Run locally
Just open `index.html` in a browser. No build step.

For service-worker + PWA features to work, you need to serve over HTTP (not `file://`). Easiest:

```bash
# any of these works
npx serve .
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy to GitHub Pages
1. Push this repo to GitHub
2. Repo **Settings → Pages**
3. Source: **Deploy from branch** → branch `main`, folder `/ (root)`
4. Save. Wait ~1 min. Your app appears at `https://<username>.github.io/<repo-name>/`
5. Open that URL on your phone → Share → **Add to Home Screen**

The home-screen icon will use the gold-and-crimson heart. Tapping it opens the app fullscreen with no browser chrome.

## File map
```
index.html              entry point
app.jsx                 main React shell, persistence, tweaks
components.jsx          calendar, status card, mood faces, icons
day-sheet.jsx           slide-up logging sheet + cycle editor
ios-frame.jsx           iPhone device-frame component (cosmetic)
tweaks-panel.jsx        floating settings panel
manifest.webmanifest    PWA manifest (app name, icons, theme)
service-worker.js       offline cache
assets/                 photo + generated app icons + splash
```

## Reset / clear data
Open the Tweaks panel (toolbar) → **Data** section → "Clear all entries" or "Reset to sample data".

Or in browser devtools: `localStorage.removeItem('haneul-cycle-v1')`.

---

사랑해 하늘아 ♡
