// components.jsx — Calendar, DaySheet, primitives for 하늘's Cycle
// Globals exported at bottom for cross-file access.

// ── tiny icon set (hand-built minimal glyphs) ────────────────────────────
const ICONS = {
  chevL: (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <path d="M12.5 4.5 7 10l5.5 5.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  chevR: (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <path d="M7.5 4.5 13 10l-5.5 5.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  heart: (size = 14, color = '#9B1C2F') => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill={color}>
      <path d="M8 14.2s-5.6-3.4-5.6-7.2A3 3 0 0 1 8 5.5 3 3 0 0 1 13.6 7C13.6 10.8 8 14.2 8 14.2Z"/>
    </svg>
  ),
  heartLine: (size = 14, color = '#B8954B') => (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
      <path d="M8 13.5s-5-3-5-6.4A2.6 2.6 0 0 1 8 5.4a2.6 2.6 0 0 1 5 1.7c0 3.4-5 6.4-5 6.4Z" stroke={color} strokeWidth="1.2"/>
    </svg>
  ),
  drop: (filled, color) => (
    <svg width="18" height="22" viewBox="0 0 18 22" fill="none">
      <path d="M9 1.5C9 1.5 2.5 8 2.5 13.2a6.5 6.5 0 0 0 13 0C15.5 8 9 1.5 9 1.5Z"
            fill={filled ? color : 'none'} stroke={color} strokeWidth="1.2"/>
    </svg>
  ),
  plus: (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M7 2v10M2 7h10" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  ),
  minus: (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M2 7h10" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  ),
  close: (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <path d="M5 5l10 10M15 5 5 15" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  ),
  edit: (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M2 12 3 9l6.5-6.5a1.4 1.4 0 0 1 2 2L5 11l-3 1Z" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round"/>
    </svg>
  ),
  spark: (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M7 1v3M7 10v3M1 7h3M10 7h3M3 3l2 2M9 9l2 2M3 11l2-2M9 5l2-2" stroke="currentColor" strokeWidth="1" strokeLinecap="round"/>
    </svg>
  ),
};

// ── date helpers ─────────────────────────────────────────────────────────
const ymd = (d) => {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
};
const fromYmd = (s) => {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
};
const sameYmd = (a, b) => ymd(a) === ymd(b);
const addDays = (d, n) => {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
};
const daysBetween = (a, b) => Math.round((b - a) / 86400000);
const monthLabel = (d) =>
  d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
const dayLabel = (d) =>
  d.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
const koMonth = (d) => `${d.getFullYear()}년 ${d.getMonth() + 1}월`;

// ── cycle math ───────────────────────────────────────────────────────────
function cycleInfo(entries, cycleLength) {
  // entries: { [ymd]: { period: bool, flow, ... } }
  const periodDates = Object.keys(entries)
    .filter((k) => entries[k]?.period)
    .sort();
  if (periodDates.length === 0) return { lastStart: null, nextStart: null, daysUntil: null, dayOfCycle: null };
  // group consecutive into clusters; lastStart = first day of most recent cluster
  const clusters = [];
  let cur = [periodDates[0]];
  for (let i = 1; i < periodDates.length; i++) {
    if (daysBetween(fromYmd(periodDates[i - 1]), fromYmd(periodDates[i])) === 1) {
      cur.push(periodDates[i]);
    } else {
      clusters.push(cur);
      cur = [periodDates[i]];
    }
  }
  clusters.push(cur);
  const lastCluster = clusters[clusters.length - 1];
  const lastStart = fromYmd(lastCluster[0]);
  const nextStart = addDays(lastStart, cycleLength);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const daysUntil = daysBetween(today, nextStart);
  const dayOfCycle = daysBetween(lastStart, today) + 1;
  return { lastStart, nextStart, daysUntil, dayOfCycle };
}

// ── Calendar ─────────────────────────────────────────────────────────────
function Calendar({ monthCursor, setMonthCursor, entries, predictedStart, onPickDay, selectedYmd }) {
  const year = monthCursor.getFullYear();
  const month = monthCursor.getMonth();
  const firstOfMonth = new Date(year, month, 1);
  const startWeekday = firstOfMonth.getDay(); // 0 = Sun
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const today = new Date(); today.setHours(0,0,0,0);

  // Build 6 weeks of cells
  const cells = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(new Date(year, month, d));
  while (cells.length % 7 !== 0) cells.push(null);

  const weekdayLabels = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  return (
    <div style={{ padding: '0 18px 14px' }}>
      {/* Month header */}
      <div style={{
        display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
        marginBottom: 10
      }}>
        <div>
          <div className="serif" style={{
            fontSize: 30, fontWeight: 500, lineHeight: 1, color: 'var(--ink)',
            letterSpacing: '-0.01em', fontStyle: 'italic'
          }}>
            {monthCursor.toLocaleDateString('en-US', { month: 'long' })}
          </div>
          <div style={{ fontSize: 11, color: 'var(--ink-mute)', marginTop: 4, letterSpacing: '0.08em' }}>
            {koMonth(monthCursor).toUpperCase()} · {year}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          <button
            onClick={() => setMonthCursor(new Date(year, month - 1, 1))}
            style={navBtnStyle} aria-label="Prev month"
          >{ICONS.chevL}</button>
          <button
            onClick={() => setMonthCursor(new Date(year, month, 1))}
            style={{ ...navBtnStyle, color: 'var(--gold-deep)', fontSize: 10, width: 'auto', padding: '0 10px' }}
            title="Jump to today"
          >TODAY</button>
          <button
            onClick={() => setMonthCursor(new Date(year, month + 1, 1))}
            style={navBtnStyle} aria-label="Next month"
          >{ICONS.chevR}</button>
        </div>
      </div>

      {/* Weekday row */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)',
        marginBottom: 4, padding: '0 2px'
      }}>
        {weekdayLabels.map((w, i) => (
          <div key={i} style={{
            textAlign: 'center', fontSize: 10, letterSpacing: '0.16em',
            color: i === 0 || i === 6 ? 'var(--crimson)' : 'var(--ink-mute)',
            fontWeight: 500, padding: '6px 0',
          }}>{w}</div>
        ))}
      </div>

      {/* Day grid */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2,
        background: 'var(--card)', borderRadius: 14, padding: 6,
        border: '1px solid var(--line-soft)',
        boxShadow: '0 1px 0 rgba(184,149,75,0.05)',
      }}>
        {cells.map((d, i) => {
          if (!d) return <div key={i} style={{ aspectRatio: '1 / 1' }} />;
          const key = ymd(d);
          const e = entries[key];
          const isPeriod = !!e?.period;
          const isToday = sameYmd(d, today);
          const isPredicted = predictedStart && sameYmd(d, predictedStart);
          const isSelected = key === selectedYmd;
          const hasNotes = !!e?.notes;
          const flowDots = e?.flow === 'heavy' ? 3 : e?.flow === 'medium' ? 2 : 1;

          return (
            <button
              key={i}
              onClick={() => onPickDay(d)}
              style={{
                position: 'relative',
                aspectRatio: '1 / 1',
                borderRadius: 10,
                background: isSelected
                  ? 'var(--gold-wash)'
                  : isPeriod
                  ? 'var(--crimson-wash)'
                  : 'transparent',
                border: isSelected ? '1px solid var(--gold)' : '1px solid transparent',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--ink)',
                transition: 'background 120ms ease',
              }}
            >
              <span style={{
                fontSize: 13, fontWeight: isToday ? 700 : 400,
                color: isPeriod ? 'var(--crimson-deep)' : 'var(--ink)',
                lineHeight: 1,
              }}>{d.getDate()}</span>

              {isToday && (
                <span style={{
                  position: 'absolute', bottom: 5, left: '50%', transform: 'translateX(-50%)',
                  width: 4, height: 4, borderRadius: 4, background: 'var(--gold)',
                }} />
              )}

              {isPeriod && (
                <span className="pulse-heart" style={{
                  position: 'absolute', top: 4, right: 4,
                  display: 'inline-flex',
                }}>{ICONS.heart(9, '#9B1C2F')}</span>
              )}

              {isPeriod && (
                <span style={{
                  position: 'absolute', bottom: 4, display: 'flex', gap: 2,
                }}>
                  {[...Array(flowDots)].map((_, k) => (
                    <span key={k} style={{
                      width: 3, height: 3, borderRadius: 3,
                      background: 'var(--crimson)',
                      opacity: 0.4 + k * 0.25,
                    }} />
                  ))}
                </span>
              )}

              {isPredicted && !isPeriod && (
                <span style={{
                  position: 'absolute', top: 4, right: 4, display: 'inline-flex',
                }}>{ICONS.heartLine(9, '#B8954B')}</span>
              )}

              {hasNotes && !isPeriod && (
                <span style={{
                  position: 'absolute', bottom: 5, width: 3, height: 3,
                  borderRadius: 3, background: 'var(--gold)',
                }} />
              )}
            </button>
          );
        })}
      </div>

      {/* Legend */}
      <div style={{
        display: 'flex', gap: 14, fontSize: 10, color: 'var(--ink-mute)',
        marginTop: 10, padding: '0 4px', flexWrap: 'wrap',
      }}>
        <LegendDot color="var(--crimson)" pulse label="Period · 생리" />
        <LegendDot color="var(--gold)" outline label="Predicted · 예상" />
        <LegendDot color="var(--gold)" small label="Note · 메모" />
      </div>
    </div>
  );
}

function LegendDot({ color, label, pulse, outline, small }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
      <span
        className={pulse ? 'pulse-heart' : ''}
        style={{
          width: small ? 5 : 8, height: small ? 5 : 8, borderRadius: 8,
          background: outline ? 'transparent' : color,
          border: outline ? `1.2px solid ${color}` : 'none',
          display: 'inline-block',
        }}
      />
      <span>{label}</span>
    </span>
  );
}

const navBtnStyle = {
  width: 30, height: 30, borderRadius: 30,
  background: 'var(--card)',
  border: '1px solid var(--line)',
  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
  color: 'var(--ink-soft)',
  fontWeight: 600, letterSpacing: '0.08em',
};

// ── Cycle Status Card ────────────────────────────────────────────────────
function StatusCard({ info, cycleLength, onEditCycle, predictionOffset, onAdjustOffset }) {
  const { daysUntil, dayOfCycle, nextStart } = info;
  const offsetDays = daysUntil ?? null;
  const status =
    daysUntil == null
      ? 'awaiting'
      : daysUntil < 0
      ? 'late'
      : daysUntil === 0
      ? 'today'
      : daysUntil <= 3
      ? 'soon'
      : 'normal';

  const headline =
    daysUntil == null
      ? { num: '—', label: 'Tap a day to log your first period' }
      : daysUntil < 0
      ? { num: Math.abs(daysUntil), label: `days late · ${Math.abs(daysUntil)}일 늦음` }
      : daysUntil === 0
      ? { num: '0', label: 'Expected today · 오늘 예상' }
      : { num: daysUntil, label: `days until next · ${daysUntil}일 후 예상` };

  return (
    <div style={{
      margin: '0 18px 14px',
      background: 'linear-gradient(180deg, #ffffff 0%, var(--bg) 120%)',
      border: '1px solid var(--line)',
      borderRadius: 18,
      padding: '16px 18px 14px',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Decorative gold corner */}
      <div style={{
        position: 'absolute', top: -30, right: -30, width: 110, height: 110,
        borderRadius: 110,
        background: 'radial-gradient(circle at 30% 30%, var(--gold-wash), transparent 70%)',
      }} />

      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <div style={{
            fontSize: 10, color: 'var(--gold-deep)', letterSpacing: '0.18em',
            fontWeight: 600, marginBottom: 4,
          }}>
            CYCLE · 주기
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span className="serif" style={{
              fontSize: 44, fontWeight: 500, lineHeight: 1,
              color: status === 'late' ? 'var(--crimson)' : 'var(--ink)',
              letterSpacing: '-0.02em',
            }}>{headline.num}</span>
            <span style={{ fontSize: 12, color: 'var(--ink-soft)', maxWidth: 130 }}>
              {headline.label}
            </span>
          </div>
        </div>
        <button
          onClick={onEditCycle}
          style={{
            border: '1px solid var(--line)', borderRadius: 999,
            padding: '5px 10px', fontSize: 10, letterSpacing: '0.1em',
            color: 'var(--ink-soft)', background: 'var(--card)',
            display: 'inline-flex', alignItems: 'center', gap: 5, fontWeight: 500,
          }}
        >
          {ICONS.edit} ADJUST
        </button>
      </div>

      <div style={{
        display: 'flex', gap: 16, marginTop: 12, paddingTop: 12,
        borderTop: '1px dashed var(--line)',
        fontSize: 11, color: 'var(--ink-soft)',
      }}>
        <StatChip k="Day" v={dayOfCycle != null ? `${dayOfCycle}` : '—'} sub="of cycle" />
        <StatChip k="Length" v={`${cycleLength}d`} sub="avg" />
        <StatChip
          k="Next"
          v={nextStart ? nextStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '—'}
          sub={nextStart ? nextStart.toLocaleDateString('ko-KR', { month: 'short', day: 'numeric' }) : ''}
        />
      </div>
    </div>
  );
}

function StatChip({ k, v, sub }) {
  return (
    <div style={{ flex: 1 }}>
      <div style={{ fontSize: 9, color: 'var(--ink-mute)', letterSpacing: '0.14em', fontWeight: 600 }}>
        {k.toUpperCase()}
      </div>
      <div style={{ fontSize: 14, color: 'var(--ink)', marginTop: 2, fontWeight: 500 }}>{v}</div>
      <div style={{ fontSize: 9, color: 'var(--ink-mute)' }}>{sub}</div>
    </div>
  );
}

// ── MoodFace — gold disc with line-drawn face ────────────────────────────
// index: 0 joyful, 1 calm, 2 neutral, 3 sad, 4 anxious
function MoodFace({ index, size = 28, active = true }) {
  const fill = active ? '#E8D9B5' : '#F1ECDD';
  const stroke = active ? '#8A6D34' : '#B8A881';
  const sw = 1.6;
  const mouth = (path) => (
    <path d={path} fill="none" stroke={stroke} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />
  );
  const eye = (cx, cy, r = 1.2) => (
    <circle cx={cx} cy={cy} r={r} fill={stroke} />
  );
  // Arched closed eyes for joyful
  const happyEye = (cx, cy) => (
    <path d={`M${cx - 1.8} ${cy + 0.4} Q${cx} ${cy - 1.4} ${cx + 1.8} ${cy + 0.4}`}
      fill="none" stroke={stroke} strokeWidth={sw} strokeLinecap="round" />
  );

  const faces = [
    // 0 Joyful — big curved smile, closed arched eyes
    <g key="0">
      {happyEye(9, 10)}
      {happyEye(15, 10)}
      {mouth('M8 14 Q12 18 16 14')}
    </g>,
    // 1 Calm — soft smile, dot eyes
    <g key="1">
      {eye(9.2, 10)}
      {eye(14.8, 10)}
      {mouth('M9 14.5 Q12 16.4 15 14.5')}
    </g>,
    // 2 Neutral — flat line mouth
    <g key="2">
      {eye(9.2, 10)}
      {eye(14.8, 10)}
      {mouth('M9 15 H15')}
    </g>,
    // 3 Sad — downturned arc
    <g key="3">
      {eye(9.2, 10.2)}
      {eye(14.8, 10.2)}
      {mouth('M9 16 Q12 13.6 15 16')}
      {/* tiny tear */}
      <path d="M15.6 12.8 Q16.2 14 15.6 14.8 Q15 14 15.6 12.8 Z" fill={stroke} opacity="0.55" />
    </g>,
    // 4 Anxious — zigzag mouth, wider eyes
    <g key="4">
      <circle cx="9" cy="10" r="1.5" fill={stroke} />
      <circle cx="15" cy="10" r="1.5" fill={stroke} />
      {mouth('M9 15.2 L10.2 14.2 L11.4 15.2 L12.6 14.2 L13.8 15.2 L15 14.2')}
      {/* worry brows */}
      {mouth('M7.6 7.6 L10.4 8.6')}
      {mouth('M16.4 7.6 L13.6 8.6')}
    </g>,
  ];

  return (
    <svg width={size} height={size} viewBox="0 0 24 24" style={{ display: 'block' }}>
      <circle cx="12" cy="12" r="11" fill={fill} stroke={stroke} strokeWidth="1" opacity={active ? 1 : 0.7}/>
      {faces[index]}
    </svg>
  );
}

Object.assign(window, {
  ICONS, ymd, fromYmd, sameYmd, addDays, daysBetween, monthLabel, dayLabel, koMonth,
  cycleInfo, Calendar, StatusCard, LegendDot, StatChip, MoodFace,
});
